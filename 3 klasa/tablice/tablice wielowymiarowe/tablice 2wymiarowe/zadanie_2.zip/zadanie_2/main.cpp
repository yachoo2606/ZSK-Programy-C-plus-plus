#include <iostream>
#include <time.h>
#include <windows.h>
#include <iomanip>

using namespace std;

int main()
{
    int tablica[10][10];
    cout<<"Losuje";
    cout<<endl;
    srand(time(NULL));
    for(int j=0;j<10;j++)
    {
        for(int i=0;i<10;i++)
        {
            tablica[i][j]=rand()%51-25;
        }
    }
    cout<<"Wylosowalem i wypisze";
    cin.get();
    cout<<endl;
    cout<<"Wy�wietlanie wierszami: ";
    cout<<endl;

    for(int j=0;j<10;j++)
    {
        cout<<"Wiersz["<<j<<"]: ";
        for(int i=0;i<10;i++)
        {
            if(j==10) cout<<setw(5)<<tablica[i][j] ;else cout<<setw(5)<<tablica[i][j]<<" ";
        }
        int najmniejsza=tablica[0][j];
        for(int i=0;i<9;i++)
            {
            if(najmniejsza>tablica[i+1][j]) najmniejsza=tablica[i+1][j];
            }
        cout<<": Najmniejsza wartosc wiersza: "<<najmniejsza;
        cout<<endl;
    }
    cout<<endl;
    cout<<"Wypisanie Kolumnami";
    cout<<endl;
    for(int i=0;i<10;i++)
    {
            cout<<"kolumna["<<i<<"]:";

            for(int j=0;j<10;j++)
            {
                if(j==10) cout<<setw(5)<<tablica[i][j];else cout<<setw(5)<<tablica[i][j]<<" ";

            }
            cout<<endl;
    }
    for(int j=0;j<10;j++)
    {
        int najmniejsza1=tablica[0][j];
        for(int i=0;i<0;i++)
        {
            if(najmniejsza1>tablica[i+1][j]) najmniejsza1=tablica[i+1][j];
        }
        cout<<": Najmniejsza wartosc wiersza: "<<najmniejsza1;
        cout<<endl;
    }
    cout<<endl;
    /*for(int i=0;i<10;i++)
    {

        for(int j=0;j<10;j++)
        {
           cout<<setw(3)<<tablica[i][j]<< " ";
        }
        cout<<endl;

    }*/
    return 0;
}
