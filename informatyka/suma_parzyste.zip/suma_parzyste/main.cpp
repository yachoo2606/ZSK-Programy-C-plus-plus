#include <iostream>
#include <fstream>
#include <windows.h>
#include <time.h>

using namespace std;

int main()
{
    fstream wej,wyj;
    int liczba,sumaparz=0,sumanieparz=0,n;

    wyj.open("Dane.txt",ios::out);
    cout<<"ile chcesz losowac: ";
    cin>>n;
    while(n>0)
    {
        wyj<<rand()%50<<endl;
        n--;
    }
    wyj.close();

    wej.open("dane.txt",ios::in);
    wyj.open("Sumy.txt",ios::out);

    if(wej.good())
    {
        cout<<"Praid�owe open!";
        while(!wej.eof())
        {
            wej>>liczba;
            if(liczba%2==0) sumaparz=sumaparz+liczba; else sumanieparz=sumanieparz+liczba;
        }
    }
    else cout<<"Bledne otwarcie!";
    wyj<<"Suma liczb nieparzystych: "<<sumanieparz<<endl;
    wyj<<"Suma liczb parzystych: "<<sumaparz;
    wej.close();
    wyj.close();
    return 0;
}
